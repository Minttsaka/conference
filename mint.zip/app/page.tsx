import AboutMe from "@/components/About";
import ContactChat from "@/components/Contact";
import EventsLifestyleSection from "@/components/EventsLifestyleSection";
import PortfolioFooter from "@/components/Footer";
import ImmersiveImageSection from "@/components/ImmersiveImageSection";
import LandingPage from "@/components/LandingPage";
import WebDevParallax from "@/components/Parallax";
import ProjectsSection from "@/components/ProjectsSection";
import SkillsConstellation from "@/components/Skills";
import { Suspense } from "react";

export default function Home() {
  return (
    <div className=" font-[family-name:var(--font-geist-sans)]">
      <Suspense>
        <LandingPage />
        <ContactChat />
        <ProjectsSection />
        <AboutMe />
        <SkillsConstellation />
        <EventsLifestyleSection />
        <ImmersiveImageSection />
        <WebDevParallax />
        <PortfolioFooter />
       </Suspense>   
    </div>
  );
}
