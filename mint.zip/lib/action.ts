"use server"

import { compileMessageTemplate, sendMail } from "./mail"

type Data = {
    email:string,
    name:string,
    message:string
}
export const sendMessage = async(data:Data) =>{

    const { email, name, message } = data

    try {
        const body = compileMessageTemplate(name, message);
        await sendMail({ from: email, subject: "New contact from portfolio", body });

    
        }
        
    catch (error) {
  
      console.log(error)
    
    }
}
